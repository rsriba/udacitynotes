#ImageAlpha

ImageAlpha is a Mac OS X GUI for [pngquant](http://pngquant.org), pngnq and [posterizer](https://github.com/pornel/mediancut-posterizer). These tools reduce filesize of PNG files while preserving the alpha channel.

ImageAlpha is written in Python and Cocoa (PyObjC).

![Screenshot](https://pngmini.com/screenshot-1.3.png)

##Sponsored By:

[PSW GROUP](https://www.psw-group.de/)

## Language Support
* 中文简体 (Chinese Simplified) - [Pluwen](https://twitter.com/pluwen)
