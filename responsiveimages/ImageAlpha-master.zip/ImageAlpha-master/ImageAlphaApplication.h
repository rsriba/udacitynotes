
#import <Cocoa/Cocoa.h>

@interface ImageAlphaApplication : NSObject
@property (retain) NSString *imageOptimPath;
@end
