//
//  IABackgroundRenderer.m
//  ImageAlpha
//
//  Created by Kornel on 25.lis.12.
//
//

#import "IABackgroundRenderer.h"

@implementation IABackgroundRenderer

-(BOOL)canMove {
    return NO;
}
@end
