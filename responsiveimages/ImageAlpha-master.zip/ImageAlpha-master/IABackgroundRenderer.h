//
//  IABackgroundRenderer.h
//  ImageAlpha
//
//  Created by Kornel on 25.lis.12.
//
//

#import <Foundation/Foundation.h>

@interface IABackgroundRenderer : NSObject
-(BOOL)canMove;
@end
